PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS peers (
    fid TEXT PRIMARY KEY,
    addr TEXT NOT NULL,
    nick TEXT,
    pubkey TEXT NOT NULL CHECK(length(pubkey) > 0),
    fingerprint TEXT,
    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    capabilities TEXT,
    verified INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_peers_last_seen ON peers(last_seen);
CREATE INDEX IF NOT EXISTS idx_peers_fingerprint ON peers(fingerprint);

CREATE TABLE IF NOT EXISTS messages (
    msg_id TEXT PRIMARY KEY,
    from_fid TEXT,
    to_addr TEXT,
    type TEXT,
    ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    envelope TEXT,
    FOREIGN KEY(from_fid) REFERENCES peers(fid) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_messages_ts ON messages(ts);

-- Replay protection: bounded cache of seen message IDs and payload hashes
CREATE TABLE IF NOT EXISTS replay_cache (
    msg_id TEXT PRIMARY KEY,
    payload_hash TEXT,
    seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_replay_cache_seen_at ON replay_cache(seen_at);

-- Rate limiting: token buckets per FID and IP
CREATE TABLE IF NOT EXISTS rate_limit (
    key TEXT PRIMARY KEY,
    tokens REAL,
    last_refill TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pending file transfers awaiting user consent
CREATE TABLE IF NOT EXISTS pending_files (
    msg_id TEXT PRIMARY KEY,
    from_fid TEXT,
    filename TEXT,
    size INTEGER,
    chunks TEXT,
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
