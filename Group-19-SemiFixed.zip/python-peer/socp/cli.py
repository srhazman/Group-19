import asyncio, sys, os
from .config import parse_args
from .storage_sqlite import Store
from .p2p import PeerNode

def main_sync():
    asyncio.run(main())

async def main():
    cfg = parse_args()
    store = Store(cfg.db_path)
    store.init_schema()

    node = PeerNode(cfg, store)
    server = await node.serve()
    
    # Beautiful welcome banner
    from .p2p import Colors
    box_width = 80
    
    def banner_line(content):
        """Format line for banner"""
        import re
        clean = re.sub(r'\033\[[0-9;]*m', '', content)
        emoji_count = len(re.findall(r'[\U0001F300-\U0001F9FF]', clean))
        padding = box_width - len(clean) - 4 - emoji_count
        return f"{Colors.BRIGHT_CYAN}║{Colors.RESET} {content}{' ' * padding} {Colors.BRIGHT_CYAN}║{Colors.RESET}"
    
    short_fid = node.fid[:16] + "..." if len(node.fid) > 20 else node.fid
    
    print(f"\n{Colors.BRIGHT_CYAN}╔{'═' * (box_width - 2)}╗{Colors.RESET}")
    print(banner_line(f"{Colors.YELLOW}🔐 SECURE CHAT - SOCP 1.3{Colors.RESET}"))
    print(f"{Colors.BRIGHT_CYAN}╠{'═' * (box_width - 2)}╣{Colors.RESET}")
    print(banner_line(f"{Colors.BOLD}Welcome, {cfg.nick}!{Colors.RESET}"))
    print(banner_line(f"{Colors.DIM}Your ID: {short_fid}{Colors.RESET}"))
    print(banner_line(f"{Colors.DIM}Server:  ws://{cfg.bind_host}:{cfg.bind_port}{Colors.RESET}"))
    print(f"{Colors.BRIGHT_CYAN}╠{'═' * (box_width - 2)}╣{Colors.RESET}")
    print(banner_line(f"{Colors.GREEN}Commands:{Colors.RESET}"))
    print(banner_line(f"  {Colors.BOLD}/list{Colors.RESET}                    - View connected users"))
    print(banner_line(f"  {Colors.BOLD}/tell <user> <text>{Colors.RESET}     - Send private message"))
    print(banner_line(f"  {Colors.BOLD}/all <text>{Colors.RESET}              - Broadcast to all users"))
    print(banner_line(f"  {Colors.BOLD}/file <user> <path>{Colors.RESET}     - Send encrypted file"))
    print(banner_line(f"  {Colors.BOLD}/accept <file> <path>{Colors.RESET}   - Accept incoming file"))
    print(banner_line(f"  {Colors.BOLD}/quit{Colors.RESET}                    - Exit application"))
    print(f"{Colors.BRIGHT_CYAN}╠{'═' * (box_width - 2)}╣{Colors.RESET}")
    print(banner_line(f"{Colors.CYAN}💡 Tip:{Colors.RESET} Use nicknames instead of FIDs!"))
    print(banner_line(f"   {Colors.DIM}Example: /tell Alice hello{Colors.RESET}"))
    print(f"{Colors.BRIGHT_CYAN}╚{'═' * (box_width - 2)}╝{Colors.RESET}\n")
    
    # Bootstrap connections
    for url in cfg.bootstrap:
        try:
            print(f"{Colors.YELLOW}[connect]{Colors.RESET} Connecting to bootstrap peer {url}...")
            await node.dial(url)
            print(f"{Colors.GREEN}[connect] ✓ Connected to {url}{Colors.RESET}")
        except Exception as e:
            print(f"{Colors.RED}[connect] ✗ Bootstrap connection to {url} failed: {e}{Colors.RESET}")

    def resolve_user(identifier):
        """Resolve nickname or FID to actual FID"""
        users = store.list_users()
        # Try exact FID match first
        for u in users:
            u_dict = dict(u)
            if u_dict['user_id'] == identifier:
                return u_dict['user_id']
        
        # Try nickname match (case-insensitive)
        for u in users:
            u_dict = dict(u)
            if u_dict.get('nick', '').lower() == identifier.lower():
                return u_dict['user_id']
        
        return None

    while True:
        line = (await asyncio.to_thread(input)).strip()
        if not line:
            continue
        if line == "/list":
            from .p2p import Colors
            import re
            import time
            users = store.list_users()
            
            if not users:
                print(f"{Colors.YELLOW}[list]{Colors.RESET} No users connected yet. Start another peer and bootstrap to connect!")
                continue
            
            box_width = 80
            
            def list_line(content):
                clean = re.sub(r'\033\[[0-9;]*m', '', content)
                emoji_count = len(re.findall(r'[\U0001F300-\U0001F9FF]', clean))
                padding = box_width - len(clean) - 4 - emoji_count
                return f"{Colors.BRIGHT_CYAN}║{Colors.RESET} {content}{' ' * padding} {Colors.BRIGHT_CYAN}║{Colors.RESET}"
            
            # Separate online and offline users (online = last_seen within 30 seconds)
            now = time.time()
            online_users = []
            offline_users = []
            
            for u in users:
                u_dict = dict(u)
                # Skip self
                if u_dict['user_id'] == node.fid:
                    continue
                    
                # Check last_seen timestamp
                last_seen_str = u_dict.get('last_seen', '')
                try:
                    import datetime
                    last_seen = datetime.datetime.fromisoformat(last_seen_str).timestamp()
                    if now - last_seen < 30:  # Online if seen in last 30 seconds
                        online_users.append(u_dict)
                    else:
                        offline_users.append(u_dict)
                except:
                    offline_users.append(u_dict)
            
            print(f"\n{Colors.BRIGHT_CYAN}╔{'═' * (box_width - 2)}╗{Colors.RESET}")
            print(list_line(f"{Colors.BOLD}👥 Connected Users{Colors.RESET}"))
            print(f"{Colors.BRIGHT_CYAN}╠{'═' * (box_width - 2)}╣{Colors.RESET}")
            
            if online_users:
                print(list_line(f"{Colors.GREEN}● Online{Colors.RESET}"))
                for u_dict in online_users:
                    nick = u_dict.get('nick', '(no nickname)')
                    fid = u_dict['user_id']
                    short_fid = fid[:50] + "..." if len(fid) > 50 else fid
                    print(list_line(f"  {Colors.BOLD}{nick:<18}{Colors.RESET} {Colors.DIM}{short_fid}{Colors.RESET}"))
            
            if offline_users:
                if online_users:
                    print(f"{Colors.BRIGHT_CYAN}╟{'─' * (box_width - 2)}╢{Colors.RESET}")
                print(list_line(f"{Colors.DIM}○ Offline (Recent){Colors.RESET}"))
                for u_dict in offline_users:
                    nick = u_dict.get('nick', '(no nickname)')
                    fid = u_dict['user_id']
                    short_fid = fid[:50] + "..." if len(fid) > 50 else fid
                    print(list_line(f"  {Colors.DIM}{nick:<18} {short_fid}{Colors.RESET}"))
            
            print(f"{Colors.BRIGHT_CYAN}╚{'═' * (box_width - 2)}╝{Colors.RESET}\n")
            
            if offline_users and not online_users:
                print(f"{Colors.YELLOW}💡 Tip:{Colors.RESET} All users are offline. Peers remain in your contacts for security.")
        elif line.startswith("/tell "):
            parts = line.split(" ",2)
            if len(parts) < 3:
                print("Usage: /tell <user> <text>")
                continue
            user_input, text = parts[1], parts[2]
            
            to_fid = resolve_user(user_input)
            if not to_fid:
                print(f"User '{user_input}' not found. Use /list to see users.")
                continue
            try:
                await node.say_private(to_fid, text)
            except Exception as e:
                print(f"DM failed: {e}")
        elif line.startswith("/all "):
            text = line.split(" ",1)[1]
            if not node.neighbours:
                print("No peers connected. Start another peer and connect with --bootstrap.")
                continue
            await node.say_public(text)  
        elif line.startswith("/file "):
            parts = line.split(" ",2)
            if len(parts) < 3:
                print("Usage: /file <user> <path>")
                continue
            user_input, path = parts[1], parts[2]
            
            to_fid = resolve_user(user_input)
            if not to_fid:
                print(f"User '{user_input}' not found. Use /list to see users.")
                continue
            if not os.path.isfile(path):
                print("File not found:", path)
                continue
            try:
                await node.send_file(to_fid, path)
            except Exception as e:
                print(f"File send failed: {e}")
        elif line.startswith("/accept "):
            parts = line.split(" ", 2)
            if len(parts) < 3:
                print("Usage: /accept <filename_or_msg_id> <output_path>")
                continue
            identifier, out_path = parts[1], parts[2]
            
            # Try to resolve filename to msg_id, or use as msg_id directly
            msg_id = identifier
            pending = store.get_pending_file(identifier)
            if not pending:
                # Try by filename
                pending = store.get_pending_file_by_name(identifier)
                if pending:
                    msg_id = pending['msg_id']
            
            # Mark the file as accepted in the peer node
            try:
                await node.accept_file(msg_id, out_path)
            except Exception as e:
                print(f"File accept failed: {e}")
        elif line == "/quit":
            break
        else:
            print("unknown command")

    server.close()
    await server.wait_closed()

if __name__ == "__main__":
    try:
        main_sync()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"File send failed: {e}")
