import sqlite3, json, os, hashlib, time

class Store:
    def __init__(self, path="var/socp.db"):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.con = sqlite3.connect(path, check_same_thread=False)
        self.con.execute("PRAGMA foreign_keys = ON")
        self.con.row_factory = sqlite3.Row

    def init_schema(self):
        
        with open("db/schema.sql","r",encoding="utf-8") as f:
            self.con.executescript(f.read())
        self.con.commit()

    def upsert_peer(self, fid, addr, nick=None, pubkey=None, fingerprint=None, capabilities=None, verified=False):
        """Only upsert peer after verification (USER_HELLO or pinned bootstrap)"""
        caps = json.dumps(capabilities) if capabilities is not None else None
        verified_int = 1 if verified else 0
        self.con.execute("""
        INSERT INTO peers(fid,addr,nick,pubkey,fingerprint,capabilities,last_seen,verified)
        VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP,?)
        ON CONFLICT(fid) DO UPDATE SET addr=excluded.addr, nick=excluded.nick, 
            pubkey=excluded.pubkey, fingerprint=excluded.fingerprint,
            capabilities=excluded.capabilities, last_seen=CURRENT_TIMESTAMP, verified=excluded.verified
        """, (fid, addr, nick, pubkey, fingerprint, caps, verified_int))
        self.con.commit()

    def get_peer(self, fid):
        """Get full peer record"""
        cur = self.con.execute("SELECT * FROM peers WHERE fid = ?", (fid,))
        return cur.fetchone()

    def get_peer_pubkey(self, fid):
        cur = self.con.execute("SELECT pubkey FROM peers WHERE fid = ?", (fid,))
        row = cur.fetchone()
        return row["pubkey"] if row else None

    def add_message(self, msg_id, from_fid, to_addr, typ, envelope_json):
        try:
            self.con.execute("""
            INSERT INTO messages(msg_id,from_fid,to_addr,type,envelope)
            VALUES(?,?,?,?,?)
            """, (msg_id, from_fid, to_addr, typ, envelope_json))
            self.con.commit()
            return True
        except sqlite3.IntegrityError:
            return False  

    def recent_peers(self, limit=50):
        cur = self.con.execute("SELECT fid, addr, nick, last_seen FROM peers ORDER BY last_seen DESC LIMIT ?", (limit,))
        return cur.fetchall()

    def list_users(self):
        cur = self.con.execute("SELECT fid as user_id, nick, pubkey, capabilities, last_seen FROM peers ORDER BY last_seen DESC")
        return cur.fetchall()

    # Replay protection
    def is_replay(self, msg_id, payload_hash=None):
        """Check if message has been seen before"""
        cur = self.con.execute("SELECT 1 FROM replay_cache WHERE msg_id = ?", (msg_id,))
        if cur.fetchone():
            return True
        if payload_hash:
            cur = self.con.execute("SELECT 1 FROM replay_cache WHERE payload_hash = ?", (payload_hash,))
            if cur.fetchone():
                return True
        return False

    def mark_seen(self, msg_id, payload_hash=None):
        """Mark message as seen for replay protection"""
        try:
            self.con.execute("INSERT INTO replay_cache(msg_id, payload_hash) VALUES(?,?)", (msg_id, payload_hash))
            self.con.commit()
        except sqlite3.IntegrityError:
            pass

    def cleanup_replay_cache(self, max_age_seconds=300):
        """Remove entries older than max_age_seconds (default 5 minutes)"""
        self.con.execute("""
        DELETE FROM replay_cache 
        WHERE seen_at < datetime('now', ? || ' seconds')
        """, (f'-{max_age_seconds}',))
        self.con.commit()

    # Rate limiting
    def get_tokens(self, key):
        """Get current token count for rate limit key"""
        cur = self.con.execute("SELECT tokens, last_refill FROM rate_limit WHERE key = ?", (key,))
        row = cur.fetchone()
        if row:
            return row['tokens'], row['last_refill']
        return None, None

    def update_tokens(self, key, tokens):
        """Update token count for rate limit key"""
        self.con.execute("""
        INSERT INTO rate_limit(key, tokens, last_refill)
        VALUES(?,?,CURRENT_TIMESTAMP)
        ON CONFLICT(key) DO UPDATE SET tokens=excluded.tokens, last_refill=CURRENT_TIMESTAMP
        """, (key, tokens))
        self.con.commit()

    # Pending files
    def add_pending_file(self, msg_id, from_fid, filename, size, chunks):
        """Store pending file awaiting user consent"""
        chunks_json = json.dumps(chunks)
        try:
            self.con.execute("""
            INSERT INTO pending_files(msg_id, from_fid, filename, size, chunks)
            VALUES(?,?,?,?,?)
            """, (msg_id, from_fid, filename, size, chunks_json))
            self.con.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def get_pending_file(self, msg_id):
        """Retrieve pending file by msg_id"""
        cur = self.con.execute("SELECT * FROM pending_files WHERE msg_id = ?", (msg_id,))
        row = cur.fetchone()
        if row:
            return {
                'msg_id': row['msg_id'],
                'from_fid': row['from_fid'],
                'filename': row['filename'],
                'size': row['size'],
                'chunks': json.loads(row['chunks'])
            }
        return None

    def remove_pending_file(self, msg_id):
        """Remove pending file after acceptance or rejection"""
        self.con.execute("DELETE FROM pending_files WHERE msg_id = ?", (msg_id,))
        self.con.commit()

    def get_pending_file_by_name(self, filename):
        """Retrieve pending file by filename (for simplified /accept command)"""
        cur = self.con.execute("SELECT * FROM pending_files WHERE filename = ? ORDER BY rowid DESC LIMIT 1", (filename,))
        row = cur.fetchone()
        if row:
            return {
                'msg_id': row['msg_id'],
                'from_fid': row['from_fid'],
                'filename': row['filename'],
                'size': row['size'],
                'chunks': json.loads(row['chunks'])
            }
        return None

