import asyncio, websockets, json, time, logging, uuid, os, hashlib, sys
from .proto import new_envelope, compact_json
from .crypto import (
    load_or_create_key, pubkey_fingerprint_and_b64,
    sign_pss_b64, verify_pss_b64,
    rsa_encrypt_b64, rsa_decrypt_b64, content_sig_b64, verify_content_sig_b64,
    validate_timestamp
)
logger = logging.getLogger(__name__)

# ANSI Color codes for better UX
class Colors:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    
    # Foreground colors
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    
    # Bright colors
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    
    @staticmethod
    def disable():
        """Disable colors on Windows if not supported"""
        if sys.platform == 'win32':
            try:
                import ctypes
                kernel32 = ctypes.windll.kernel32
                kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            except:
                pass  # Colors might not work, but continue anyway

# Enable colors on Windows
Colors.disable()

class PeerNode:
    def __init__(self, cfg, store):
        self.cfg = cfg
        self.store = store
        self.addr = f"ws://{cfg.bind_host}:{cfg.bind_port}"
        self.neighbours = set()
        self.pending_id = {}  # fid -> {addr,nick,pubkey,ts}
        self._trusted_bootstrap = self._load_trusted_bootstrap()
        
        
        keypath = os.path.join("var", f"node_key_{self.cfg.bind_port}.pem")
        key_password = os.environ.get("SOCP_KEY_PASSWORD")  # Optional password for encrypted keys
        self.sk = load_or_create_key(path=keypath, password=key_password)  
        self.fid, self.my_pub_b64 = pubkey_fingerprint_and_b64(self.sk)
        fingerprint = self.fid.split(":")[1] if ":" in self.fid else self.fid[:16]
        try:
            self.store.upsert_peer(self.fid, self.addr, nick=self.cfg.nick, pubkey=self.my_pub_b64, 
                                   fingerprint=fingerprint, verified=True)
        except Exception:
            logger.exception("Failed to upsert local peer")
        
    def _canonical_bytes_for_sig(self, env: dict) -> bytes:
        """
        Produce canonical JSON bytes for signing/verifying.
        We remove 'sig' and 'ttl' before canonicalising so relays can change ttl.
        """
        env_copy = {k: v for k, v in env.items() if k not in ("sig", "ttl")}
        s = compact_json(env_copy)
        return s.encode()

    def _get_nickname(self, fid: str) -> str:
        """Get nickname for a FID, or return truncated FID if no nickname"""
        users = self.store.list_users()
        for u in users:
            u_dict = dict(u)
            if u_dict['user_id'] == fid:
                nick = u_dict.get('nick', '')
                if nick:
                    return nick
        # Return shortened FID if no nickname
        return fid[:8] + "..." if len(fid) > 16 else fid

    def _sign_env(self, env: dict) -> None:
        """Attach 'sig' to env using our private key and canonical bytes."""
        canon = self._canonical_bytes_for_sig(env)
        env["sig"] = sign_pss_b64(self.sk, canon)

    def _verify_env_sig(self, env: dict) -> bool:
        """Verify envelope signature using stored peer pubkey (if known)."""
        sender = env.get("from")
        sig = env.get("sig")
        if not sig:
            return False
        sender_pub = self.store.get_peer_pubkey(sender)
        if not sender_pub:
            return False
        canon = self._canonical_bytes_for_sig(env)
        return verify_pss_b64(sender_pub, sig, canon)

    def _fid_from_pub_b64(self, pub_b64: str) -> str:
        try:
            pem = self._b64url_decode(pub_b64)
        except Exception:
            return ""
        h = hashlib.sha256(pem).hexdigest()
        return f"fid:{h[:16]}"

    @staticmethod
    def _b64url_decode(s: str) -> bytes:
        pad = (-len(s)) % 4
        return __import__("base64").urlsafe_b64decode(s + ("=" * pad))

    def _load_trusted_bootstrap(self) -> dict:
        """Load a pinned FID->pubkey map from JSON. Path can be overridden by SOCP_TRUSTED_BOOTSTRAP env var.
        Default: ./trusted_bootstrap.json. Missing file -> {}.
        """
        path = os.environ.get("SOCP_TRUSTED_BOOTSTRAP", os.path.join(os.getcwd(), "trusted_bootstrap.json"))
        try:
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        return data
        except Exception:
            logger.warning("Failed to load trusted bootstrap from %s", path)
        return {}

    def _check_rate_limit(self, key: str, max_tokens: float = 10.0, refill_rate: float = 1.0) -> bool:
        """
        Token bucket rate limiting.
        key: identifier (fid or IP address)
        max_tokens: bucket capacity
        refill_rate: tokens per second
        Returns True if allowed, False if rate limited
        """
        now = time.time()
        tokens, last_refill_str = self.store.get_tokens(key)
        
        if tokens is None:
            # First request from this key
            tokens = max_tokens - 1
            self.store.update_tokens(key, tokens)
            return True
        
        # Parse last_refill timestamp
        try:
            import datetime
            last_refill = datetime.datetime.fromisoformat(last_refill_str).timestamp()
        except:
            last_refill = now
        
        # Refill tokens based on elapsed time
        elapsed = now - last_refill
        tokens = min(max_tokens, tokens + elapsed * refill_rate)
        
        if tokens >= 1.0:
            tokens -= 1
            self.store.update_tokens(key, tokens)
            return True
        else:
            # Rate limited
            return False

    async def _send_error(self, ws, code: str, reason: str, to_fid: str = None):
        if ws is None:
            return
        env = new_envelope(typ="ERROR", to=to_fid or "group:public", frm=self.fid, ttl=1,
                           body={"code": code, "reason": reason})
        self._sign_env(env)  # Sign error messages
        try:
            await ws.send(compact_json(env))
        except Exception:
            pass

    async def serve(self):
        async def handler(ws):
            peer_fid = None
            self.neighbours.add(ws)
            try:
                async for line in ws:
                    await self.on_frame(ws, line)
                    # Track peer FID for disconnect message
                    if not peer_fid:
                        try:
                            env = json.loads(line)
                            peer_fid = env.get("from")
                        except:
                            pass
            except websockets.exceptions.ConnectionClosedError:
                # Clean disconnect - peer closed gracefully or network issue
                if peer_fid:
                    nickname = self._get_nickname(peer_fid)
                    print(f"\n{Colors.YELLOW}[disconnect]{Colors.RESET} {Colors.BOLD}{nickname}{Colors.RESET} has left the chat")
            except Exception as e:
                # Unexpected error
                if peer_fid:
                    nickname = self._get_nickname(peer_fid)
                    print(f"\n{Colors.RED}[disconnect]{Colors.RESET} {Colors.BOLD}{nickname}{Colors.RESET} disconnected unexpectedly: {e}")
                else:
                    logger.exception("Connection handler failed")
            finally:
                self.neighbours.discard(ws)
        
        asyncio.create_task(self.heartbeat())
        return await websockets.serve(handler, self.cfg.bind_host, self.cfg.bind_port, max_size=1_000_000)

    async def heartbeat(self):
        while True:
            await asyncio.sleep(15)
            env = new_envelope(typ="HEARTBEAT", to="group:public", frm=self.fid, ttl=2, body={})
            self._sign_env(env)
            frame = compact_json(env)
            for n in list(self.neighbours):
                try:
                    await n.send(frame)
                except Exception:
                    self.neighbours.discard(n)


    async def dial(self, url):
        # Enforce TLS for non-localhost if configured
        if self.cfg.require_tls and not url.startswith("wss://"):
            # Check if target is localhost
            import re
            host_match = re.search(r'ws://([^:/]+)', url)
            if host_match:
                host = host_match.group(1)
                if host not in ("localhost", "127.0.0.1", "::1"):
                    logger.error(f"TLS required for non-localhost connection: {url}")
                    print(f"[error] TLS required for remote connections. Use wss:// instead of ws://")
                    return
        
        ws = await websockets.connect(url, open_timeout=5)
        self.neighbours.add(ws)
        asyncio.create_task(self.reader(ws))
        await self.send_hello(ws)

    async def reader(self, ws):
        peer_fid = None
        try:
            async for line in ws:
                await self.on_frame(ws, line)
                # Track peer FID for disconnect message
                if not peer_fid:
                    try:
                        env = json.loads(line)
                        peer_fid = env.get("from")
                    except:
                        pass
        except websockets.exceptions.ConnectionClosedError:
            # Clean disconnect - peer closed gracefully or network issue
            if peer_fid:
                nickname = self._get_nickname(peer_fid)
                print(f"\n{Colors.YELLOW}[disconnect]{Colors.RESET} {Colors.BOLD}{nickname}{Colors.RESET} has left the chat")
        except Exception as e:
            # Unexpected error
            if peer_fid:
                nickname = self._get_nickname(peer_fid)
                print(f"\n{Colors.RED}[disconnect]{Colors.RESET} {Colors.BOLD}{nickname}{Colors.RESET} disconnected unexpectedly")
            logger.exception("Reader task failed")
        finally:
            self.neighbours.discard(ws)

    async def on_frame(self, ws, line):
        try:
            env = json.loads(line)
        except Exception:
            return

        msg_id = env.get("msg_id")
        if not msg_id:
            msg_id = env.get("ts") 
        if not msg_id:
            return
        
        # Replay protection: check both msg_id and payload hash
        payload_hash = hashlib.sha256(line.encode() if isinstance(line, str) else line).hexdigest()
        if self.store.is_replay(msg_id, payload_hash):
            logger.debug("Replay detected: %s", msg_id)
            return
        
        # Mark as seen for replay protection
        self.store.mark_seen(msg_id, payload_hash)
        
        # Timestamp freshness validation (skip for HELLO which may not have strict timing)
        ts = env.get("ts")
        if ts and env.get("type") not in ("HELLO",):
            if not validate_timestamp(ts):
                logger.warning("Timestamp validation failed for msg_id=%s type=%s", msg_id, env.get("type"))
                await self._send_error(ws, "STALE_MESSAGE", "Message too old or in future", to_fid=env.get("from"))
                return
        
        # Rate limiting by sender FID
        sender_fid = env.get("from")
        if sender_fid and sender_fid != self.fid:
            if not self._check_rate_limit(f"fid:{sender_fid}", max_tokens=20.0, refill_rate=2.0):
                logger.warning("Rate limit exceeded for %s", sender_fid)
                await self._send_error(ws, "RATE_LIMIT", "Too many requests", to_fid=sender_fid)
                return

        
        if env.get("type") == "HELLO":
            body = env.get("body", {}) or {}
            peer_fid = env.get("from")
            peer_addr = body.get("addr", "unknown")
            peer_nick = body.get("nick")
            peer_pub = body.get("pubkey")
            # Do NOT upsert on plain HELLO. Enforce bootstrap pinning and defer updates until USER_HELLO.
            # Bootstrap pinning: if this looks like a bootstrap seed address, require pinned key to match.
            if peer_addr and self.cfg.bootstrap and peer_addr in set(self.cfg.bootstrap or []):
                pinned = self._trusted_bootstrap.get(peer_fid)
                if pinned and peer_pub and pinned != peer_pub:
                    logger.warning("Pinned key mismatch for bootstrap %s", peer_fid)
                    await self._send_error(ws, "INVALID_KEY", "Pinned bootstrap key mismatch", to_fid=peer_fid)
                    return
                if pinned and pinned == peer_pub:
                    # Accept immediately based on trusted pin
                    try:
                        fingerprint = peer_fid.split(":")[1] if ":" in peer_fid else peer_fid[:16]
                        self.store.upsert_peer(peer_fid, peer_addr, nick=peer_nick, pubkey=pinned, 
                                               fingerprint=fingerprint, verified=True)
                    except Exception:
                        logger.exception("upsert_peer (pinned) failed for %s", peer_fid)
                    return
            # Otherwise, store as pending; require USER_HELLO with valid signature
            self.pending_id[peer_fid] = {
                "addr": peer_addr,
                "nick": peer_nick,
                "pubkey": peer_pub,
                "ts": int(time.time() * 1000)
            }
            # Send our own USER_HELLO in response so they can verify us
            await self.send_user_hello(ws)
            return
        elif env.get("type") == "USER_HELLO":
            # Signed identity assertion. Verify signature and binding of fid to pubkey before upsert.
            body = env.get("body", {}) or {}
            peer_fid = env.get("from")
            cand_pub = None
            if peer_fid in self.pending_id and self.pending_id[peer_fid].get("pubkey"):
                cand_pub = self.pending_id[peer_fid]["pubkey"]
            elif body.get("pubkey"):
                cand_pub = body.get("pubkey")
            if not cand_pub:
                logger.warning("USER_HELLO without candidate pubkey for %s", peer_fid)
                return
            # Verify fid matches pubkey fingerprint
            if peer_fid != self._fid_from_pub_b64(cand_pub):
                logger.warning("USER_HELLO fid/pubkey mismatch for %s", peer_fid)
                await self._send_error(ws, "INVALID_KEY", "fid does not match pubkey")
                return
            # Verify signature over canonical bytes with candidate pubkey
            sig = env.get("sig")
            if not sig:
                logger.warning("Dropping unsigned USER_HELLO from %s", peer_fid)
                return
            canon = self._canonical_bytes_for_sig(env)
            if not verify_pss_b64(cand_pub, sig, canon):
                logger.warning("Invalid USER_HELLO signature from %s", peer_fid)
                await self._send_error(ws, "INVALID_SIG", "USER_HELLO signature invalid")
                return
            # Prevent unauthorized key change for existing peers
            existing = self.store.get_peer_pubkey(peer_fid)
            if existing and existing != cand_pub:
                logger.warning("Key change attempt for %s rejected", peer_fid)
                await self._send_error(ws, "INVALID_KEY_CHANGE", "Key change not allowed")
                return
            # Upsert now that identity is verified
            try:
                addr = body.get("addr") or (self.pending_id.get(peer_fid, {}).get("addr") if peer_fid in self.pending_id else "unknown")
                nick = body.get("nick") or (self.pending_id.get(peer_fid, {}).get("nick") if peer_fid in self.pending_id else None)
                fingerprint = peer_fid.split(":")[1] if ":" in peer_fid else peer_fid[:16]
                self.store.upsert_peer(peer_fid, addr, nick=nick, pubkey=cand_pub, 
                                       fingerprint=fingerprint, verified=True)
            except Exception:
                logger.exception("upsert_peer (USER_HELLO) failed for %s", peer_fid)
            finally:
                self.pending_id.pop(peer_fid, None)
            # Do not fall through to generic processing for USER_HELLO
            return
            
        else:
            # Transport signature verification for all non-HELLO/USER_HELLO frames
            sig = env.get("sig")
            sender = env.get("from")
            if not sig:
                logger.warning("Dropping unsigned frame type=%s from %s", env.get("type"), sender)
                await self._send_error(ws, "INVALID_SIG", "Missing transport signature", to_fid=sender)
                return

            sender_pub = self.store.get_peer_pubkey(sender)
            if not sender_pub:
                logger.warning("No known pubkey for %s; dropping frame type=%s", sender, env.get("type"))
                await self._send_error(ws, "UNKNOWN_SENDER", "No known pubkey", to_fid=sender)
                return

            try:
                canon = compact_json({k: v for k, v in env.items() if k not in ("sig", "ttl")}).encode()
                if not verify_pss_b64(sender_pub, sig, canon):
                    logger.warning("Invalid signature from %s; dropping", sender)
                    await self._send_error(ws, "INVALID_SIG", "Transport signature invalid", to_fid=sender)
                    return
            except Exception:
                logger.exception("Signature verification error for %s", sender)
                await self._send_error(ws, "INVALID_SIG", "Transport signature error", to_fid=sender)
                return

        
        # Only persist last_seen for non-HELLO messages (HELLO processing handled above without DB mutation)
        sender_fid = env.get("from", "unknown")
        if env.get("type") not in ("HELLO", "USER_HELLO"):
            try:
                # Update last_seen timestamp for known peers (do not create new peers here)
                peer = self.store.get_peer(sender_fid)
                if peer:
                    # sqlite3.Row doesn't support .get(), use dict() or direct access with fallback
                    fingerprint = peer["fingerprint"] if "fingerprint" in peer.keys() else None
                    verified = peer["verified"] if "verified" in peer.keys() else False
                    self.store.upsert_peer(sender_fid, peer["addr"], nick=peer["nick"], 
                                           pubkey=peer["pubkey"], fingerprint=fingerprint,
                                           verified=verified)
            except Exception:
                logger.exception("upsert_peer failed for persist")

        if env.get("type") == "CHAT":
            to = env.get("to")
            body = env.get("body", {}) or {}

            
            if body.get("enc") == "RSA-OAEP-SHA256" and "cipher" in body:
                
                if to == self.fid:
                    try:
                        pt = rsa_decrypt_b64(self.sk, body["cipher"])
                        inner = json.loads(pt.decode())
                        nickname = self._get_nickname(env.get('from'))
                        print(f"{Colors.MAGENTA}[pm]{Colors.RESET} {Colors.BOLD}{nickname}{Colors.RESET}: {inner.get('text')}")
                    except Exception:
                        logger.exception("Failed to decrypt private chat from %s", env.get("from"))
            else:
                
                nickname = self._get_nickname(env.get('from'))
                if to and str(to).startswith("group:"):
                    print(f"{Colors.CYAN}[public]{Colors.RESET} {Colors.BOLD}{nickname}{Colors.RESET}: {body.get('text','')}")
                else:
                    print(f"{Colors.MAGENTA}[pm]{Colors.RESET} {Colors.BOLD}{nickname}{Colors.RESET}: {body.get('text','')}")
        elif env.get("type") == "MSG_PUBLIC_CHANNEL":
            payload = env.get("payload", {})
            sender = env.get("from")
            ciphertext = payload.get("ciphertext")
            sender_pub = payload.get("sender_pub")
            c_sig = payload.get("content_sig")
            # Verify content signature before decrypting or displaying
            if not (ciphertext and sender_pub and c_sig):
                logger.warning("Missing content fields in MSG_PUBLIC_CHANNEL from %s", sender)
                return
            if not verify_content_sig_b64(sender_pub, c_sig, ciphertext, env.get("from"), env.get("to"), env.get("ts")):
                logger.warning("Invalid content signature in MSG_PUBLIC_CHANNEL from %s", sender)
                await self._send_error(ws, "INVALID_CONTENT_SIG", "Content signature invalid", to_fid=sender)
                return
            try:
                pt = rsa_decrypt_b64(self.sk, ciphertext)
                nickname = self._get_nickname(sender)
                print(f"{Colors.CYAN}[public]{Colors.RESET} {Colors.BOLD}{nickname}{Colors.RESET}: {pt.decode(errors='ignore')}")
            except Exception:
                nickname = self._get_nickname(sender)
                print(f"{Colors.CYAN}[public]{Colors.RESET} {Colors.BOLD}{nickname}{Colors.RESET}: {Colors.RED}<unable to decrypt>{Colors.RESET}")
        elif env.get("type") == "MSG_DIRECT":
            # Optional support: verify content signature for direct messages as well
            payload = env.get("payload", {})
            sender = env.get("from")
            ciphertext = payload.get("ciphertext")
            sender_pub = payload.get("sender_pub")
            c_sig = payload.get("content_sig")
            if not (ciphertext and sender_pub and c_sig):
                logger.warning("Missing content fields in MSG_DIRECT from %s", sender)
                return
            if not verify_content_sig_b64(sender_pub, c_sig, ciphertext, env.get("from"), env.get("to"), env.get("ts")):
                logger.warning("Invalid content signature in MSG_DIRECT from %s", sender)
                await self._send_error(ws, "INVALID_CONTENT_SIG", "Content signature invalid", to_fid=sender)
                return
            # Decrypt and print if addressed to us
            if env.get("to") == self.fid:
                try:
                    pt = rsa_decrypt_b64(self.sk, ciphertext)
                    inner = json.loads(pt.decode())
                    nickname = self._get_nickname(env.get('from'))
                    print(f"{Colors.MAGENTA}[pm]{Colors.RESET} {Colors.BOLD}{nickname}{Colors.RESET}: {inner.get('text','')}")
                except Exception:
                    logger.exception("Failed to decrypt MSG_DIRECT from %s", env.get("from"))
        
        # After type-specific validation/processing, persist the message once we know it's valid
        try:
            self.store.add_message(msg_id, env.get("from"), env.get("to"), env.get("type"), line)
        except Exception:
            logger.exception("add_message failed")
        
        if env.get("type") == "FILE_START":
            payload = env.get("payload", {})
            file_id = payload.get("file_id")
            name = payload.get("name")
            size = payload.get("size")
            sha256 = payload.get("sha256")
            
            if env.get("to") == self.fid:
                # Store file offer in pending_files table (requires user consent via /accept)
                from_fid = env.get("from")
                msg_id = env.get("msg_id", file_id)
                nickname = self._get_nickname(from_fid)
                
                # Pretty file offer with colors and border - calculate proper width
                box_width = 70
                
                # Truncate long names for display
                display_name = name if len(name) <= 40 else name[:37] + "..."
                display_nick = nickname if len(nickname) <= 40 else nickname[:37] + "..."
                
                def format_line(content, width=box_width):
                    """Format a line to fit exactly in the box"""
                    # Remove ANSI codes for length calculation
                    import re
                    clean = re.sub(r'\033\[[0-9;]*m', '', content)
                    # Count emojis (they take 2 char width but len() counts as 1)
                    emoji_count = len(re.findall(r'[\U0001F300-\U0001F9FF]', clean))
                    # Width - 2 borders - 2 spaces - extra space for emojis
                    padding = width - len(clean) - 4 - emoji_count
                    return f"{Colors.BRIGHT_CYAN}║{Colors.RESET} {content}{' ' * padding} {Colors.BRIGHT_CYAN}║{Colors.RESET}"
                
                print(f"\n{Colors.BRIGHT_CYAN}╔{'═' * (box_width - 2)}╗{Colors.RESET}")
                print(format_line(f"{Colors.YELLOW}📩 FILE INCOMING{Colors.RESET}"))
                print(f"{Colors.BRIGHT_CYAN}╠{'═' * (box_width - 2)}╣{Colors.RESET}")
                print(format_line(f"{Colors.BOLD}From:{Colors.RESET} {display_nick}"))
                print(format_line(f"{Colors.BOLD}File:{Colors.RESET} {display_name}"))
                print(format_line(f"{Colors.BOLD}Size:{Colors.RESET} {size:,} bytes"))
                print(f"{Colors.BRIGHT_CYAN}╠{'═' * (box_width - 2)}╣{Colors.RESET}")
                print(format_line(f"{Colors.GREEN}To accept:{Colors.RESET} {Colors.BOLD}/accept {display_name} <save_path>{Colors.RESET}"))
                print(format_line(f"{Colors.DIM}Example:   /accept {display_name} downloads/{display_name}{Colors.RESET}"))
                print(format_line(f"{Colors.DIM}Or ignore this message if you don't wish to accept from {display_nick}{Colors.RESET}"))
                print(f"{Colors.BRIGHT_CYAN}╚{'═' * (box_width - 2)}╝{Colors.RESET}\n")
                
                # Store pending file offer
                try:
                    self.store.add_pending_file(msg_id, from_fid, name, size, {"file_id": file_id})
                except Exception:
                    logger.exception("Failed to store pending file")
                
                # Initialize buffer but mark as pending (not accepted yet)
                if not hasattr(self, "file_buffers"):
                    self.file_buffers = {}
                self.file_buffers[file_id] = {
                    "chunks": {}, 
                    "name": name, 
                    "size": size, 
                    "sha256": sha256, 
                    "from": from_fid,
                    "msg_id": msg_id,
                    "accepted": False,  # REQUIRES USER CONSENT
                    "save_path": None
                }
        elif env.get("type") == "FILE_CHUNK":
            payload = env.get("payload", {})
            file_id = payload.get("file_id")
            idx = payload.get("index")
            ct = payload.get("ciphertext")
            if env.get("to") == self.fid and hasattr(self, "file_buffers") and file_id in self.file_buffers:
                try:
                    chunk = rsa_decrypt_b64(self.sk, ct)
                    self.file_buffers[file_id]["chunks"][idx] = chunk
                except Exception:
                    logger.exception("Failed to decrypt file chunk")
        elif env.get("type") == "FILE_END":
            payload = env.get("payload", {})
            file_id = payload.get("file_id")
            if env.get("to") == self.fid and hasattr(self, "file_buffers") and file_id in self.file_buffers:
                buf = self.file_buffers[file_id]
                
                # Mark that all chunks have been received
                buf["all_chunks_received"] = True
                
                # Check if user has accepted this file
                if not buf.get("accepted"):
                    print(f"{Colors.YELLOW}[file]{Colors.RESET} Received all chunks for '{buf['name']}', waiting for acceptance...")
                    # Keep buffer for when user accepts
                    return
                
                # User has accepted - save the file
                chunks = [buf["chunks"][i] for i in sorted(buf["chunks"])]
                data = b"".join(chunks)
            
                sha256 = hashlib.sha256(data).hexdigest()
                if sha256 != buf["sha256"]:
                    print(f"{Colors.RED}[file] ✗ Hash mismatch for '{buf['name']}'{Colors.RESET}")
                else:
                    save_path = buf.get("save_path") or f"recv_{buf['name']}"
                    
                    # Create directory if needed
                    import os
                    os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else ".", exist_ok=True)
                    
                    with open(save_path, "wb") as f:
                        f.write(data)
                    
                    # Success message with border
                    nickname = self._get_nickname(buf['from'])
                    box_width = 70
                    
                    # Truncate long paths/names
                    display_name = buf['name'] if len(buf['name']) <= 50 else buf['name'][:47] + "..."
                    display_nick = nickname if len(nickname) <= 50 else nickname[:47] + "..."
                    display_path = save_path if len(save_path) <= 50 else "..." + save_path[-47:]
                    
                    def format_line(content, width=box_width):
                        import re
                        clean = re.sub(r'\033\[[0-9;]*m', '', content)
                        emoji_count = len(re.findall(r'[\U0001F300-\U0001F9FF]', clean))
                        padding = width - len(clean) - 4 - emoji_count
                        return f"{Colors.GREEN}║{Colors.RESET} {content}{' ' * padding} {Colors.GREEN}║{Colors.RESET}"
                    
                    print(f"\n{Colors.GREEN}╔{'═' * (box_width - 2)}╗{Colors.RESET}")
                    print(format_line(f"{Colors.BOLD}✓ FILE SAVED{Colors.RESET}"))
                    print(f"{Colors.GREEN}╠{'═' * (box_width - 2)}╣{Colors.RESET}")
                    print(format_line(f"File: {display_name}"))
                    print(format_line(f"From: {display_nick}"))
                    print(format_line(f"Path: {display_path}"))
                    print(f"{Colors.GREEN}╚{'═' * (box_width - 2)}╝{Colors.RESET}\n")
                
                # Clean up
                del self.file_buffers[file_id]
                try:
                    self.store.remove_pending_file(buf.get('msg_id'))
                except Exception:
                    pass

        
        try:
            ttl = int(env.get("ttl", 0)) - 1
        except Exception:
            ttl = -1
        if ttl <= 0:
            return
        env["ttl"] = ttl
        out = compact_json(env)
        for n in list(self.neighbours):
            if n is ws:
                continue
            try:
                await n.send(out)
            except Exception:
                self.neighbours.discard(n)


    async def send_hello(self, ws):
        env = new_envelope(typ="HELLO", to="group:public", frm=self.fid, ttl=2,
                           body={"nick": self.cfg.nick, "addr": self.addr, "pubkey": self.my_pub_b64})
        
        self._sign_env(env)
        await ws.send(compact_json(env))
        # Follow with a signed USER_HELLO that recipients can verify before trusting identity
        await self.send_user_hello(ws)

    async def send_user_hello(self, ws):
        env = new_envelope(typ="USER_HELLO", to="group:public", frm=self.fid, ttl=2,
                           body={"nick": self.cfg.nick, "addr": self.addr, "pubkey": self.my_pub_b64})
        self._sign_env(env)
        await ws.send(compact_json(env))

    async def say_public(self, text):
        env = new_envelope(typ="CHAT", to="group:public", frm=self.fid, ttl=6, body={"text": text})
        self._sign_env(env)
        frame = compact_json(env)
        for n in list(self.neighbours):
            try:
                await n.send(frame)
            except Exception:
                self.neighbours.discard(n)

    async def send_file(self, to_fid, path):
        import uuid, hashlib, os
        file_id = str(uuid.uuid4())
        size = os.path.getsize(path)
        name = os.path.basename(path)
        
        # File size limit (10 MB)
        MAX_FILE_SIZE = 10 * 1024 * 1024
        if size > MAX_FILE_SIZE:
            logger.error(f"File too large: {size} bytes (max {MAX_FILE_SIZE})")
            print(f"{Colors.RED}[file] ✗ File too large ({size:,} bytes, max {MAX_FILE_SIZE:,}){Colors.RESET}")
            return
        
        with open(path, "rb") as f:
            data = f.read()
        sha256 = hashlib.sha256(data).hexdigest()
        
        # Send FILE_START (follows SOCP spec structure)
        manifest = {
            "type": "FILE_START",
            "from": self.fid,
            "to": to_fid,
            "msg_id": uuid.uuid4().hex,
            "ts": int(time.time() * 1000),
            "payload": {
                "file_id": file_id,
                "name": name,
                "size": size,
                "sha256": sha256,
                "mode": "dm"
            }
        }
        self._sign_env(manifest)  
        frame = compact_json(manifest)
        for n in list(self.neighbours):
            try:
                await n.send(frame)
            except Exception:
                self.neighbours.discard(n)
        
        # Send FILE_CHUNKs (once each)
        # RSA-2048 with OAEP-SHA256 can only encrypt ~190 bytes
        # Use smaller chunks to stay within RSA encryption limits
        RSA_MAX_PLAINTEXT = 190  # Safe limit for RSA-2048 + OAEP-SHA256
        chunk_size = RSA_MAX_PLAINTEXT
        
        recipient_pub = self.store.get_peer_pubkey(to_fid)
        if not recipient_pub:
            logger.error(f"No pubkey for {to_fid}")
            print(f"{Colors.RED}[file] ✗ Unknown recipient public key{Colors.RESET}")
            return
        
        total_chunks = (len(data) + chunk_size - 1) // chunk_size
        nickname = self._get_nickname(to_fid)
        print(f"\n{Colors.CYAN}[file] 🔒 Encrypting {name} for {nickname}...{Colors.RESET}")
        print(f"{Colors.DIM}[file] Size: {size:,} bytes → {total_chunks} encrypted chunks{Colors.RESET}")
        
        for i in range(0, len(data), chunk_size):
            chunk = data[i:i+chunk_size]
            chunk_num = i // chunk_size
            
            # Show progress bar
            progress = (chunk_num + 1) / total_chunks
            bar_length = 40
            filled = int(bar_length * progress)
            bar = "█" * filled + "░" * (bar_length - filled)
            percent = progress * 100
            print(f"\r{Colors.YELLOW}[file]{Colors.RESET} [{Colors.GREEN}{bar}{Colors.RESET}] {Colors.BOLD}{percent:5.1f}%{Colors.RESET} ({chunk_num+1}/{total_chunks} chunks)", end="", flush=True)
            
            try:
                ct = rsa_encrypt_b64(recipient_pub, chunk)
            except Exception as e:
                print()  # New line after progress bar
                logger.exception("File chunk encryption failed")
                print(f"{Colors.RED}[file] ✗ Encryption failed for chunk {chunk_num}{Colors.RESET}")
                return
            chunk_msg = {
                "type": "FILE_CHUNK",
                "from": self.fid,
                "to": to_fid,
                "msg_id": uuid.uuid4().hex,
                "ts": int(time.time() * 1000),
                "payload": {
                    "file_id": file_id,
                    "index": i // chunk_size,
                    "ciphertext": ct
                }
            }
            self._sign_env(chunk_msg) 
            frame = compact_json(chunk_msg)
            for n in list(self.neighbours):
                try:
                    await n.send(frame)
                except Exception:
                    self.neighbours.discard(n)
        
        print()  # New line after progress bar completes
        print(f"{Colors.GREEN}[file] ✓ Encryption complete! Sending to {nickname}...{Colors.RESET}")
        
        # Send FILE_END (once)
        end_msg = {
            "type": "FILE_END",
            "from": self.fid,
            "to": to_fid,
            "msg_id": uuid.uuid4().hex,
            "ts": int(time.time() * 1000),
            "payload": {"file_id": file_id}
        }
        self._sign_env(end_msg) 
        frame = compact_json(end_msg)
        for n in list(self.neighbours):
            try:
                await n.send(frame)
            except Exception:
                self.neighbours.discard(n)

    async def say_private(self, to_fid, text):
        recipient_pub = self.store.get_peer_pubkey(to_fid)
        if not recipient_pub:
            raise RuntimeError("Unknown recipient pubkey for " + str(to_fid))
        
        inner = {"text": text}
        pt = compact_json(inner).encode()
        cipher_b64 = rsa_encrypt_b64(recipient_pub, pt)
        body = {"cipher": cipher_b64, "enc": "RSA-OAEP-SHA256"}
        env = new_envelope(typ="CHAT", to=to_fid, frm=self.fid, ttl=6, body=body)
        self._sign_env(env)
        frame = compact_json(env)
        for n in list(self.neighbours):
            try:
                await n.send(frame)
            except Exception:
                self.neighbours.discard(n)

    async def accept_file(self, msg_id, save_path):
        """Accept a pending file transfer and save to specified path."""
        # Find the file_id from pending files
        pending = self.store.get_pending_file(msg_id)
        if not pending:
            print(f"{Colors.RED}[file] ✗ No pending file found{Colors.RESET}")
            print(f"{Colors.YELLOW}[file] Check file offers above or wait for transfer to complete{Colors.RESET}")
            return
        
        file_id = pending.get("chunks", {}).get("file_id")
        if not file_id:
            print(f"{Colors.RED}[file] ✗ Invalid file record{Colors.RESET}")
            return
        
        # Check if file buffer exists
        if not hasattr(self, "file_buffers") or file_id not in self.file_buffers:
            print(f"{Colors.YELLOW}[file] ⏳ Waiting for file chunks to arrive for '{pending.get('filename')}'...{Colors.RESET}")
            # Still mark as accepted so it saves when FILE_END arrives
            if hasattr(self, "file_buffers") and file_id in self.file_buffers:
                self.file_buffers[file_id]["accepted"] = True
                self.file_buffers[file_id]["save_path"] = save_path
            return
        
        # Mark file as accepted
        buf = self.file_buffers[file_id]
        buf["accepted"] = True
        buf["save_path"] = save_path
        
        nickname = self._get_nickname(buf['from'])
        print(f"{Colors.GREEN}[file] ✓ Accepted '{buf['name']}' from {nickname}{Colors.RESET}")
        print(f"{Colors.GREEN}[file] → Saving to: {save_path}{Colors.RESET}")
        
        # If all chunks already received (FILE_END already arrived), save now
        if "all_chunks_received" in buf:
            chunks = [buf["chunks"][i] for i in sorted(buf["chunks"])]
            data = b"".join(chunks)
            
            import hashlib
            sha256 = hashlib.sha256(data).hexdigest()
            if sha256 != buf["sha256"]:
                print(f"{Colors.RED}[file] ✗ Hash mismatch for '{buf['name']}'{Colors.RESET}")
            else:
                import os
                os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else ".", exist_ok=True)
                
                with open(save_path, "wb") as f:
                    f.write(data)
                
                # Success message with border
                nickname = self._get_nickname(buf['from'])
                box_width = 70
                
                display_name = buf['name'] if len(buf['name']) <= 50 else buf['name'][:47] + "..."
                display_nick = nickname if len(nickname) <= 50 else nickname[:47] + "..."
                display_path = save_path if len(save_path) <= 50 else "..." + save_path[-47:]
                
                def format_line(content, width=box_width):
                    import re
                    clean = re.sub(r'\033\[[0-9;]*m', '', content)
                    emoji_count = len(re.findall(r'[\U0001F300-\U0001F9FF]', clean))
                    padding = width - len(clean) - 4 - emoji_count
                    return f"{Colors.GREEN}║{Colors.RESET} {content}{' ' * padding} {Colors.GREEN}║{Colors.RESET}"
                
                print(f"\n{Colors.GREEN}╔{'═' * (box_width - 2)}╗{Colors.RESET}")
                print(format_line(f"{Colors.BOLD}✓ FILE SAVED{Colors.RESET}"))
                print(f"{Colors.GREEN}╠{'═' * (box_width - 2)}╣{Colors.RESET}")
                print(format_line(f"File: {display_name}"))
                print(format_line(f"From: {display_nick}"))
                print(format_line(f"Path: {display_path}"))
                print(f"{Colors.GREEN}╚{'═' * (box_width - 2)}╝{Colors.RESET}\n")
            
            # Clean up
            del self.file_buffers[file_id]
            try:
                self.store.remove_pending_file(msg_id)
            except Exception:
                pass

