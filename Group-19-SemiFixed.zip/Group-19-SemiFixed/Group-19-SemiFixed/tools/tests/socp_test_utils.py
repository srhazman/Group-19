import json
import socket
import time

def test_message_formats():
    """Test various SOCP message formats"""
    test_messages = [
        {"type": "HELLO", "username": "testuser"},
        {"type": "CHAT", "username": "testuser", "message": "Hello world"},
        {"type": "PUBLIC_CHAT", "username": "testuser", "message": "Public message"},
        {"type": "LEAVE", "username": "testuser"}
    ]
    
    for msg in test_messages:
        try:
            json_msg = json.dumps(msg)
            print(f" Valid JSON: {json_msg}")
        except Exception as e:
            print(f" JSON Error: {e}")

def test_server_connectivity(host, port):
    """Test connection to server"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((host, port))
        print(f" Connected to {host}:{port}")
        sock.close()
        return True
    except Exception as e:
        print(f" Connection failed: {e}")
        return False

if __name__ == "__main__":
    print("=== SOCP Message Format Testing ===")
    test_message_formats()
    
    print("\n=== Server Connectivity Testing ===")
    test_server_connectivity("localhost", 8080)
    test_server_connectivity("localhost", 3000)
    test_server_connectivity("localhost", 5000)
    
    print("\n=== Testing Complete ===")