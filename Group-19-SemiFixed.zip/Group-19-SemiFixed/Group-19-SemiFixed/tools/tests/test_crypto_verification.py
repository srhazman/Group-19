"""
SOCP Cryptography Verification Suite

This test verifies that the implementation correctly uses:
- RSA-4096 key generation
- RSA-OAEP-SHA256 encryption/decryption
- RSA-PSS-SHA256 signatures
- Protocol-compliant content signatures
- Chunked encryption for large messages
"""

import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'python-peer'))

from socp.crypto import (
    load_or_create_key, 
    pubkey_fingerprint_and_b64,
    rsa_encrypt_b64, 
    rsa_decrypt_b64,
    sign_pss_b64, 
    verify_pss_b64,
    content_sig_b64, 
    verify_content_sig_b64,
    rsa_encrypt_chunks_b64,
    rsa_decrypt_chunks
)


def test_rsa_4096_generation():
    """Verify RSA-4096 key generation"""
    print("Testing RSA-4096 key generation...")
    
    tmp_fd, tmp_path = tempfile.mkstemp()
    os.close(tmp_fd) 
    os.unlink(tmp_path) 
    
    try:
        sk = load_or_create_key(tmp_path)
        
        key_size = sk.key_size
        print(f"  Key size: {key_size} bits")
        assert key_size == 4096, f"Expected 4096-bit key, got {key_size}"
        
        public_exponent = sk.public_key().public_numbers().e
        print(f"  Public exponent: {public_exponent}")
        assert public_exponent == 65537, f"Expected exponent 65537, got {public_exponent}"
        
        print("  RSA-4096 key generation verified")
        return sk
    
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def test_rsa_oaep_sha256():
    """Verify RSA-OAEP-SHA256 encryption/decryption"""
    print("Testing RSA-OAEP-SHA256 encryption/decryption...")
    
    sk = test_rsa_4096_generation()
    fid, pub_b64 = pubkey_fingerprint_and_b64(sk)
    
    test_message = b"Hello, this is a test message for RSA-OAEP-SHA256!"
    print(f"  Original message: {test_message}")
    
    ciphertext_b64 = rsa_encrypt_b64(pub_b64, test_message)
    print(f"  Encrypted (base64url): {ciphertext_b64[:50]}...")
    
    decrypted = rsa_decrypt_b64(sk, ciphertext_b64)
    print(f"  Decrypted message: {decrypted}")
    
    assert decrypted == test_message, f"Decryption failed: {decrypted} != {test_message}"
    print("  RSA-OAEP-SHA256 encryption/decryption verified")
    
    return sk, pub_b64


def test_rsa_pss_sha256():
    """Verify RSA-PSS-SHA256 signatures"""
    print("Testing RSA-PSS-SHA256 signatures...")
    
    sk, pub_b64 = test_rsa_oaep_sha256()
    
    test_data = b"This is test data for RSA-PSS-SHA256 signature verification"
    print(f"  Data to sign: {test_data}")
    
    signature_b64 = sign_pss_b64(sk, test_data)
    print(f"  Signature (base64url): {signature_b64[:50]}...")
    
    valid = verify_pss_b64(pub_b64, signature_b64, test_data)
    print(f"  Signature verification result: {valid}")
    assert valid, "Valid signature failed verification"
    
    tampered_data = b"This is TAMPERED data for RSA-PSS-SHA256 signature verification"
    invalid = verify_pss_b64(pub_b64, signature_b64, tampered_data)
    print(f"  Tampered data verification result: {invalid}")
    assert not invalid, "Tampered data should fail verification"
    
    print("  RSA-PSS-SHA256 signature/verification verified")
    return sk, pub_b64


def test_content_signature():
    """Verify protocol content signature format"""
    print("Testing protocol content signatures...")
    
    sk, pub_b64 = test_rsa_pss_sha256()
    
    message = b"Hello Alice!"
    ciphertext_b64 = rsa_encrypt_b64(pub_b64, message)
    frm = "fid:sender123"
    to = "fid:recipient456"
    ts = int(time.time() * 1000)
    
    print(f"  Testing content signature for:")
    print(f"    From: {frm}")
    print(f"    To: {to}")
    print(f"    Timestamp: {ts}")
    print(f"    Ciphertext: {ciphertext_b64[:30]}...")
    
    content_sig = content_sig_b64(sk, ciphertext_b64, frm, to, ts)
    print(f"  Content signature: {content_sig[:50]}...")
    
    valid = verify_content_sig_b64(pub_b64, content_sig, ciphertext_b64, frm, to, ts)
    print(f"  Content signature verification: {valid}")
    assert valid, "Content signature verification failed"
    
    wrong_ts = ts + 1000
    invalid = verify_content_sig_b64(pub_b64, content_sig, ciphertext_b64, frm, to, wrong_ts)
    print(f"  Wrong timestamp verification: {invalid}")
    assert not invalid, "Wrong timestamp should fail verification"
    
    print("   Protocol content signature verified")
    return sk, pub_b64


def test_chunked_encryption():
    """Test RSA encryption for large messages"""
    print("Testing chunked RSA encryption for large messages...")
    
    sk, pub_b64 = test_content_signature()
    
    large_message = b"A" * 1000 
    print(f"  Large message size: {len(large_message)} bytes")
    
    chunks = rsa_encrypt_chunks_b64(pub_b64, large_message)
    print(f"  Message split into {len(chunks)} chunks")
    print(f"  First chunk: {chunks[0][:50]}...")
    
    decrypted = rsa_decrypt_chunks(sk, chunks)
    print(f"  Decrypted size: {len(decrypted)} bytes")
    
    assert decrypted == large_message, "Chunked encryption/decryption failed"
    print("   Chunked RSA encryption verified")


def test_key_persistence():
    """Test that keys are properly persisted and loaded"""
    print("Testing key persistence and loading...")
    
    tmp_fd, tmp_path = tempfile.mkstemp()
    os.close(tmp_fd)  
    os.unlink(tmp_path)  
    
    try:
        sk1 = load_or_create_key(tmp_path)
        fid1, pub_b641 = pubkey_fingerprint_and_b64(sk1)
        
        sk2 = load_or_create_key(tmp_path)
        fid2, pub_b642 = pubkey_fingerprint_and_b64(sk2)
        
        assert fid1 == fid2, f"FIDs don't match: {fid1} != {fid2}"
        assert pub_b641 == pub_b642, "Public keys don't match"
        
        print(f"  Key FID: {fid1}")
        print(f"  Public key: {pub_b641[:50]}...")
        print("   Key persistence verified")
        
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def test_password_protected_keys():
    """Test password-protected key storage"""
    print("Testing password-protected key storage...")
    
    
    tmp_fd, tmp_path = tempfile.mkstemp()
    os.close(tmp_fd)  
    os.unlink(tmp_path)
    
    try:
        password = "test_password_123"
        
        
        sk1 = load_or_create_key(tmp_path, password=password)
        fid1, pub_b641 = pubkey_fingerprint_and_b64(sk1)
        
        
        sk2 = load_or_create_key(tmp_path, password=password)
        fid2, pub_b642 = pubkey_fingerprint_and_b64(sk2)
        
    
        assert fid1 == fid2, f"FIDs don't match: {fid1} != {fid2}"
        assert pub_b641 == pub_b642, "Public keys don't match"
        
        print(f"  Password-protected key FID: {fid1}")
        print("   Password-protected key storage verified")
        
        try:
            load_or_create_key(tmp_path, password="wrong_password")
            assert False, "Should have failed with wrong password"
        except Exception:
            print("   Wrong password correctly rejected")
        
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def run_all_crypto_tests():
    """Run complete cryptographic verification suite"""
    print("=" * 60)
    print("SOCP Cryptography Verification Suite")
    print("=" * 60)
    
    try:
        print("\n1. Testing RSA-4096 Key Generation...")
        test_rsa_4096_generation()
        
        print("\n2. Testing RSA-OAEP-SHA256 Encryption...")
        test_rsa_oaep_sha256()
        
        print("\n3. Testing RSA-PSS-SHA256 Signatures...")
        test_rsa_pss_sha256()
        
        print("\n4. Testing Protocol Content Signatures...")
        test_content_signature()
        
        print("\n5. Testing Chunked Encryption...")
        test_chunked_encryption()
        
        print("\n6. Testing Key Persistence...")
        test_key_persistence()
        
        print("\n7. Testing Password-Protected Keys...")
        test_password_protected_keys()
        
        print("\n" + "=" * 60)
        print(" ALL CRYPTOGRAPHIC TESTS PASSED")
        print(" Implementation correctly uses:")
        print("  - RSA-4096 key generation (public exponent 65537)")
        print("  - RSA-OAEP-SHA256 encryption with MGF1-SHA256")
        print("  - RSA-PSS-SHA256 signatures with max salt length")
        print("  - Protocol-compliant content signatures")
        print("  - Proper chunking for large messages")
        print("  - Key persistence and password protection")
        print("=" * 60)
        print("\n SOCP CRYPTOGRAPHY IMPLEMENTATION IS PROTOCOL-COMPLIANT")
        
    except Exception as e:
        print(f"\n CRYPTOGRAPHIC TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        raise


if __name__ == "__main__":
    run_all_crypto_tests()