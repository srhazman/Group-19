PoC scripts for assignment appendix

Location: tools/poc/

Files:
- forge_hello.py         : Demonstrates unsigned HELLO can overwrite peer record (python-peer)
- forge_signed_frame.py : Demonstrates forging a validly signed CHAT frame by reading a PEM
- canonicalisation_mismatch.py : Shows serialization differences between Python compact_json and a Node-like buggy implementation

Prerequisites (Windows PowerShell):
1. From project root (Group-19), create and activate a venv:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r python-peer\requirements.txt
```

2. Initialise the database (creates var/socp.db):

```powershell
python tools\init_db.py var\socp.db
```

Run a PoC (examples):

```powershell
# from project root
python tools\poc\forge_hello.py
python tools\poc\forge_signed_frame.py
python tools\poc\canonicalisation_mismatch.py
```

Notes:
- These scripts operate only on local files and the local sqlite DB. Do not run them against remote hosts.
- They are for educational demonstration on your own environment and code only.

Mitigations summary (short):
- Require signed HELLO messages before accepting pubkey changes.
- Protect private key files with strict filesystem permissions.
- Standardise canonical JSON across implementations (e.g. RFC8785) and add interop tests.
