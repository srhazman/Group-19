"""
PoC: Canonicalisation / encoding mismatch between Python and Node-like behaviour
Run: python tools\poc\canonicalisation_mismatch.py

This script demonstrates that the Python `compact_json` and a Node-like buggy `compactJson`
(represented here in Python) can produce different serializations for the same envelope.
"""
import json
from pprint import pprint
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'python-peer'))
from socp.proto import compact_json


def node_like_compact_json(obj):
    # mimic the Node implementation bug: sort keys recursively, then call JSON.stringify(obj, replacerArray)
    def sort_rec(o):
        if o is None:
            return None
        if isinstance(o, list):
            return [sort_rec(x) for x in o]
        if isinstance(o, dict):
            out = {}
            for k in sorted(o.keys()):
                out[k] = sort_rec(o[k])
            return out
        return o

    s = sort_rec(obj)
    replacer = list(s.keys()) if isinstance(s, dict) else []

    # Node's JSON.stringify(obj, replacerArray) uses the replacer array only at top-level keys but then
    # when serializing nested objects it still applies the replacer (in JS it applies to each object using the same array)
    # which will drop nested keys not present in the top-level list. We mimic that behavior here.
    def serialize(o):
        if o is None:
            return "null"
        if isinstance(o, bool):
            return "true" if o else "false"
        if isinstance(o, (int, float)):
            return json.dumps(o)
        if isinstance(o, str):
            return json.dumps(o)
        if isinstance(o, list):
            return "[" + ",".join(serialize(x) for x in o) + "]"
        if isinstance(o, dict):
            items = []
            # use top-level replacer for every object
            for k in replacer:
                if k in o:
                    items.append(json.dumps(k) + ":" + serialize(o[k]))
            return "{" + ",".join(items) + "}"
        raise TypeError(type(o))

    return serialize(s)


def main():
    env = {
        "v": "0.1",
        "type": "CHAT",
        "msg_id": "abcdef123456",
        "from": "fid:example",
        "to": "group:public",
        "ttl": 6,
        "ts": 1697900000000,
        "body": {
            "text": "hello",
            "inner": {"b": 2, "a": 1}
        }
    }

    py = compact_json(env)
    node_like = node_like_compact_json(env)

    print("Python compact_json:")
    print(py)
    print("\nNode-like compact_json:")
    print(node_like)
    print("\nDifferent:", py != node_like)

if __name__ == '__main__':
    main()
